dev_test folder can be used to test resource and libraries without formal user stories.

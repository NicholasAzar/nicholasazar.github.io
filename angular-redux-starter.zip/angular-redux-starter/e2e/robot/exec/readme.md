to run the .bash files run the following command in a terminal from root

bash exec/filename.bash

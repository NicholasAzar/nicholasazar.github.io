exports.HmrState = function() {

}

class ContactAddressController {
  constructor() {
    this.name = 'Our Address';
    this.address = 'Bornheimer Straße 37; 531111 Bonn';
  }
}

export default ContactAddressController;

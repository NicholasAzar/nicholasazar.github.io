class ContactController {
  constructor() {
    this.name = 'Contact Us';
  }
}

export default ContactController;

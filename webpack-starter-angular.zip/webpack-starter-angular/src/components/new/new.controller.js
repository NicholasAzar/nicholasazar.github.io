class NewController {
  constructor() {
    this.name = 'New Component Syntax';
  }
}

export default NewController;

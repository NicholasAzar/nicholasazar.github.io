import template from './app.html';

let appComponent = () => {
  return {
    template,
    restrict: 'E'
  };
};

export default appComponent;
